package com.adel.pes2013img

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.Locale

private data class AfEntry(val index: Int, val offset: Long, val size: Long)
private data class Payload(val file: File, val offset: Long, val size: Long)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var archiveFile: File? = null
    private var entries: List<AfEntry> = emptyList()
    private var selected = -1
    private lateinit var info: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val labels = mutableListOf<String>()
    private val displayLabels = mutableListOf<String>()
    private val visibleIndices = mutableListOf<Int>()
    private val entryNames = mutableListOf<String>()
    private lateinit var searchBox: EditText
    private val phoneLabels = mutableListOf<String>()
    private val phoneFiles = mutableListOf<File>()
    private val phoneRawNames = mutableListOf<String>()
    private var nameTableRecords: List<ByteArray>? = null
    private lateinit var phoneAdapter: ArrayAdapter<String>
    private var phoneSelected = -1
    private var pendingExport: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cleanOldCache()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8) }
        val title = TextView(this).apply { text = "PES 2013 IMG Explorer V9"; textSize = 20f; gravity = Gravity.CENTER; setPadding(0,6,0,8) }
        info = TextView(this).apply { text = "افتح IMG في اليسار، واختر ملفات الهاتف في اليمين."; textSize = 13f; setPadding(4,4,4,8) }
        fun button(caption: String, action: () -> Unit) = Button(this).apply { text = caption; setOnClickListener { action() } }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayLabels)
        phoneAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, phoneLabels)
        val archiveList = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _,_,p,_-> selected=visibleIndices.getOrElse(p) { -1 }; showSelected() }
        }
        val phoneList = ListView(this).apply {
            this.adapter = this@MainActivity.phoneAdapter
            setOnItemClickListener { _, _, p, _ ->
                phoneSelected = p
                info.text = "ملف الهاتف: ${phoneLabels.getOrNull(p) ?: ""}"
            }
        }
        val headers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        headers.addView(TextView(this).apply { text="محتويات IMG"; gravity=Gravity.CENTER; textSize=16f }, LinearLayout.LayoutParams(0,-2,1f))
        headers.addView(TextView(this).apply { text="ملفات الهاتف"; gravity=Gravity.CENTER; textSize=16f }, LinearLayout.LayoutParams(0,-2,1f))
        val panes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panes.addView(archiveList, LinearLayout.LayoutParams(0,-1,1f))
        panes.addView(phoneList, LinearLayout.LayoutParams(0,-1,1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row1.addView(button("فتح IMG") { pickOpen() }, LinearLayout.LayoutParams(0,-2,1f))
        row1.addView(button("اختيار ملفات الهاتف") { pick(15,true) }, LinearLayout.LayoutParams(0,-2,1f))
        val row2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row2.addView(button("إضافة / نقل") { addPhoneFiles() }, LinearLayout.LayoutParams(0,-2,1f))
        row2.addView(button("استبدال المحدد") { replaceFromPhone() }, LinearLayout.LayoutParams(0,-2,1f))
        row2.addView(button("استبدال الكل تلقائياً") { replaceAllMatching() }, LinearLayout.LayoutParams(0,-2,1f))
        val row3 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row3.addView(button("استخراج") { exportSelected() }, LinearLayout.LayoutParams(0,-2,1f))
        row3.addView(button("حذف") { deleteSelected() }, LinearLayout.LayoutParams(0,-2,1f))
        row3.addView(button("حفظ نسخة IMG") { pickSave() }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(row1); actions.addView(row2); actions.addView(row3)
        searchBox = EditText(this).apply {
            hint = "بحث برقم أو اسم الملف..."
            setSingleLine(true)
            textSize = 14f
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applySearch(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(title); root.addView(info); root.addView(searchBox); root.addView(headers); root.addView(panes, LinearLayout.LayoutParams(-1,0,1f)); root.addView(actions)
        setContentView(root)
    }

    private fun pickOpen() = pick(10)
    private fun pick(request: Int, multiple: Boolean = false) {
        if (request in listOf(11,14) && archiveFile == null) { toast("افتح IMG أولاً"); return }
        if (request == 11 && selected !in entries.indices) { toast("اختر عنصراً أولاً"); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE); if(multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true) }
        startActivityForResult(i, request)
    }
    private fun pickSave() {
        if (archiveFile == null) { toast("افتح IMG أولاً"); return }
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/octet-stream"; putExtra(Intent.EXTRA_TITLE,"PES2013_modified.img") },12)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data==null) return
        val uris=mutableListOf<Uri>()
        data.clipData?.let { c -> for(i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        if(uris.isEmpty()) data.data?.let { uris.add(it) }
        if(uris.isEmpty()) return
        when(requestCode) {
            10 -> runIo("جارٍ فحص ملف IMG...") {
                val f=copyUriToTemp(uris[0],"opened_")
                val parsed=parseAfs(f)
                replaceArchive(f, parsed); selected=-1
                refresh("تم فتح الملف — ${parsed.size} مدخل — ${f.length()} بايت")
            }
            11 -> runIo("جارٍ استبدال العنصر...") {
                val replacement=copyUriToTemp(uris[0],"replacement_")
                val old=archiveFile!!
                val payloads=entries.map { e -> if(e.index==selected) Payload(replacement,0,replacement.length()) else Payload(old,e.offset,e.size) }
                val out=buildAfs(payloads); replaceArchive(out, parseAfs(out)); replacement.delete(); selected=-1; refresh("تم الاستبدال. احفظ IMG جديداً.")
            }
            12 -> runIo("جارٍ حفظ IMG...") { archiveFile!!.inputStream().buffered().use { input -> contentResolver.openOutputStream(uris[0],"w")!!.buffered().use { input.copyTo(it) } }; status("تم حفظ IMG المعدل") }
            13 -> runIo("جارٍ تصدير العنصر...") { val f=pendingExport ?: return@runIo; f.inputStream().buffered().use { input -> contentResolver.openOutputStream(uris[0],"w")!!.buffered().use { input.copyTo(it) } }; f.delete(); pendingExport=null; status("تم تصدير العنصر") }
            14 -> runIo("جارٍ إضافة الملفات...") {
                val old=archiveFile!!
                val payloads=entries.map { Payload(old,it.offset,it.size) }.toMutableList()
                val temps=mutableListOf<File>()
                try {
                    uris.forEach { u -> val f=copyUriToTemp(u,"added_"); temps.add(f); payloads.add(Payload(f,0,f.length())) }
                    val out=buildAfs(payloads)
                    replaceArchive(out, parseAfs(out)); selected=entries.lastIndex
                    refresh("تمت إضافة ${uris.size} ملف/ملفات. احفظ IMG جديداً.")
                } finally { temps.forEach { it.delete() } }
            }
            15 -> runIo("جارٍ تجهيز ملفات الهاتف...") {
                val copied = uris.map { u ->
                    val name = queryDisplayName(u) ?: "phone_file_${System.nanoTime()}.bin"
                    val f = copyUriToTemp(u,"phone_")
                    name to f
                }
                phoneFiles.forEach { it.delete() }
                phoneFiles.clear(); phoneLabels.clear(); phoneRawNames.clear()
                copied.forEach { (name,file) ->
                    phoneFiles.add(file)
                    phoneRawNames.add(name)
                    phoneLabels.add(String.format(Locale.US, "%s  |  %,d bytes", name, file.length()))
                }
                phoneSelected = if(phoneFiles.isNotEmpty()) 0 else -1
                runOnUiThread { phoneAdapter.notifyDataSetChanged(); info.text = "تم اختيار ${phoneFiles.size} ملف من الهاتف. حدد الملف ثم اضغط إضافة / نقل." }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if(c.moveToFirst()) return c.getString(0)
        }
        return null
    }
    // يستبدل مدخل IMG مباشرة بالملف المحدد في القائمة اليمنى.
    private fun replaceFromPhone() {
        if (archiveFile == null) { toast("افتح IMG أولاً"); return }
        if (selected !in entries.indices) { toast("حدد ملفاً من القائمة اليسرى أولاً"); return }
        if (phoneSelected !in phoneFiles.indices) { toast("حدد ملفاً من القائمة اليمنى أولاً"); return }
        val targetIndex = selected
        val replacement = phoneFiles[phoneSelected]
        runIo("جارٍ استبدال الملف المحدد...") {
            val old = archiveFile!!
            val payloads = entries.map { e ->
                if (e.index == targetIndex) Payload(replacement, 0, replacement.length())
                else Payload(old, e.offset, e.size)
            }
            val out = buildAfs(payloads)
            replaceArchive(out, parseAfs(out))
            selected = targetIndex
            refresh("تم استبدال ${displayName(targetIndex)} بالملف المحدد من الهاتف. احفظ نسخة IMG.")
        }
    }

    private fun replaceAllMatching() {
        if (archiveFile == null) { toast("افتح IMG أولاً"); return }
        if (phoneFiles.isEmpty()) { toast("اختر ملفات الهاتف أولاً"); return }
        val regex = Regex("""^(?:unnamed_|entry_)?(\d+)(?:\.[^.]+)?$""", RegexOption.IGNORE_CASE)
        val replacements = linkedMapOf<Int, File>()
        phoneRawNames.forEachIndexed { i, raw ->
            val base = raw.substringAfterLast('/').substringBeforeLast('.')
            val number = regex.matchEntire(base)?.groupValues?.get(1)?.toIntOrNull()
            if (number != null && entries.any { it.index == number }) replacements[number] = phoneFiles[i]
        }
        if (replacements.isEmpty()) {
            toast("لم يتم العثور على أسماء مطابقة مثل unnamed_66.bin")
            return
        }
        runIo("جارٍ تجهيز ${replacements.size} عملية استبدال...") {
            val old = archiveFile ?: throw IllegalStateException("لا يوجد IMG مفتوح")
            val payloads = entries.map { e ->
                val replacement = replacements[e.index]
                if (replacement != null) Payload(replacement, 0, replacement.length())
                else Payload(old, e.offset, e.size)
            }
            val out = buildAfs(payloads)
            replaceArchive(out, parseAfs(out))
            selected = -1
            refresh("تم استبدال ${replacements.size} ملف دفعة واحدة. احفظ نسخة IMG.")
        }
    }

    private fun addPhoneFiles() {
        if(archiveFile==null) { toast("افتح IMG أولاً"); return }
        if(phoneFiles.isEmpty()) { toast("اختر ملفات الهاتف أولاً"); return }
        val chosen = if(phoneSelected in phoneFiles.indices) listOf(phoneSelected) else phoneFiles.indices.toList()
        runIo("جارٍ نقل الملفات إلى IMG...") {
            val old=archiveFile!!
            val payloads=entries.map { Payload(old,it.offset,it.size) }.toMutableList()
            chosen.forEach { i -> val f=phoneFiles[i]; payloads.add(Payload(f,0,f.length())) }
            val out=buildAfs(payloads); replaceArchive(out, parseAfs(out)); selected=entries.lastIndex
            refresh("تمت إضافة ${chosen.size} ملف. لم يتم استبدال العناصر القديمة تلقائياً لأن أسماء AFS الداخلية لم تُتحقق بعد؛ استخدم استبدال المحدد عند التأكد من العنصر.")
        }
    }

    // لا نحذف الأرشيف القديم إلا بعد اكتمال بناء وقراءة الأرشيف الجديد بنجاح.
    private fun replaceArchive(newFile: File, newEntries: List<AfEntry>) {
        val oldFile = archiveFile
        archiveFile = newFile
        entries = newEntries
        if (oldFile != null && oldFile.absoluteFile != newFile.absoluteFile &&
            oldFile.parentFile == cacheDir &&
            (oldFile.name.startsWith("rebuilt_") || oldFile.name.startsWith("opened_"))) {
            oldFile.delete()
        }
    }

    private fun cleanOldCache() {
        // حذف الملفات المؤقتة القديمة فقط؛ لا نحذف الأرشيف الحالي أو ملفات الهاتف المستخدمة.
        cacheDir.listFiles()?.forEach { f ->
            if ((f.name.startsWith("rebuilt_") || f.name.startsWith("opened_") ||
                 f.name.startsWith("replacement_") || f.name.startsWith("added_") ||
                 f.name.startsWith("export_") || f.name.startsWith("phone_")) && f != archiveFile && f != pendingExport) {
                f.delete()
            }
        }
    }

    private fun copyUriToTemp(uri:Uri,prefix:String):File {
        val f=File(cacheDir,"${prefix}${System.nanoTime()}.bin")
        contentResolver.openInputStream(uri)!!.buffered().use { input -> f.outputStream().buffered().use { input.copyTo(it,1024*1024) } }
        return f
    }
    private fun parseAfs(file:File):List<AfEntry> {
        RandomAccessFile(file,"r").use { r ->
            require(r.length()>=8) { "الملف أصغر من ترويسة AFS" }
            val h=ByteArray(8); r.readFully(h)
            require(h[0]==0x41.toByte() && h[1]==0x46.toByte() && h[2]==0x53.toByte() && h[3]==0.toByte()) { "التوقيع ليس AFS\\0" }
            val count=ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).getInt(4)
            require(count in 1..200000) { "عدد العناصر غير منطقي: $count" }
            val tocEnd=8L+count.toLong()*8L
            require(tocEnd<=r.length()) { "جدول العناصر خارج حدود الملف" }
            val result=ArrayList<AfEntry>(count); val b=ByteArray(8)
            repeat(count) { i ->
                r.seek(8L+i*8L); r.readFully(b)
                val bb=ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                val off=bb.int.toLong() and 0xffffffffL
                val size=bb.int.toLong() and 0xffffffffL
                require(off<=r.length() && size<=r.length()-off) { "مدخل $i خارج حدود الملف" }
                result.add(AfEntry(i,off,size))
            }
            // CRI AFS optional filename directory: offset/length pair immediately after TOC,
            // followed by one 48-byte record per entry.
            nameTableRecords = null
            if (tocEnd + 8 <= r.length()) {
                r.seek(tocEnd)
                val pair=ByteArray(8); r.readFully(pair)
                val pb=ByteBuffer.wrap(pair).order(ByteOrder.LITTLE_ENDIAN)
                val dirOffset=pb.int.toLong() and 0xffffffffL
                val dirLength=pb.int.toLong() and 0xffffffffL
                val lastDataByte = result.maxOfOrNull { it.offset + it.size } ?: 0L
                if (dirOffset > 0 && dirLength == count.toLong()*48L &&
                    dirOffset >= lastDataByte && dirOffset <= r.length() &&
                    dirLength <= r.length()-dirOffset) {
                    val records=ArrayList<ByteArray>(count)
                    r.seek(dirOffset)
                    repeat(count) {
                        val record=ByteArray(48); r.readFully(record)
                        records.add(record)
                    }
                    nameTableRecords=records
                }
            }
            return result
        }
    }

    private fun buildAfs(payloads:List<Payload>):File {
        require(payloads.isNotEmpty() && payloads.size<=200000) { "عدد العناصر غير صالح" }
        val out=File(cacheDir,"rebuilt_${System.nanoTime()}.img")
        val offsets=LongArray(payloads.size); val sizes=LongArray(payloads.size)
        val oldRecords=nameTableRecords
        val keepNames=oldRecords != null
        val records=if (keepNames) payloads.indices.map { i ->
            (oldRecords!!.getOrNull(i)?.copyOf() ?: newNameRecord(i)).also { record ->
                val previousSize=entries.getOrNull(i)?.size
                val stored=ByteBuffer.wrap(record,44,4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
                if (previousSize != null && stored == previousSize)
                    ByteBuffer.wrap(record,44,4).order(ByteOrder.LITTLE_ENDIAN).putInt(payloads[i].size.toInt())
            }
        } else emptyList()
        try {
            RandomAccessFile(out,"rw").use { dst ->
                dst.setLength(0)
                dst.write(ByteArray(align(8L+payloads.size*8L+8L,0x800L).toInt()))
                payloads.forEachIndexed { i,p ->
                    val pos=align(dst.filePointer,0x800L); dst.seek(pos); offsets[i]=pos; sizes[i]=p.size
                    p.file.inputStream().use { input -> input.skipFully(p.offset); copyExactly(input,dst,p.size) }
                    dst.seek(align(dst.filePointer,0x800L))
                }
                var directoryOffset=0L
                var directoryLength=0L
                if (keepNames) {
                    directoryOffset=align(dst.filePointer,0x800L)
                    dst.seek(directoryOffset)
                    records.forEach { dst.write(it) }
                    directoryLength=records.size.toLong()*48L
                }
                require(dst.length()<=0xffffffffL) { "حجم IMG تجاوز حد AFS" }
                dst.seek(0); dst.write(byteArrayOf(0x41,0x46,0x53,0)); writeIntLE(dst,payloads.size)
                offsets.indices.forEach { i ->
                    require(offsets[i]<=0xffffffffL && sizes[i]<=0xffffffffL)
                    writeIntLE(dst,offsets[i].toInt()); writeIntLE(dst,sizes[i].toInt())
                }
                writeIntLE(dst,directoryOffset.toInt()); writeIntLE(dst,directoryLength.toInt())
            }
            return out
        } catch (t: Throwable) {
            out.delete()
            throw t
        }
    }

    private fun newNameRecord(index:Int):ByteArray {
        val record=ByteArray(48)
        val name="unnamed_$index.bin".toByteArray(Charsets.US_ASCII)
        System.arraycopy(name,0,record,0,minOf(name.size,31))
        return record
    }

    private fun copyExactly(input:InputStream,out:RandomAccessFile,size:Long) { val buf=ByteArray(1024*1024); var left=size; while(left>0) { val n=input.read(buf,0,minOf(buf.size.toLong(),left).toInt()); if(n<0) throw EOFException("انتهى الملف قبل اكتمال العنصر"); out.write(buf,0,n); left-=n } }
    private fun InputStream.skipFully(n:Long) { var left=n; while(left>0) { val s=skip(left); if(s<=0) { if(read()==-1) throw EOFException(); left-- } else left-=s } }
    private fun writeIntLE(r:RandomAccessFile,v:Int) { r.write(v and 255); r.write((v ushr 8) and 255); r.write((v ushr 16) and 255); r.write((v ushr 24) and 255) }
    private fun align(v:Long,a:Long)=((v+a-1)/a)*a

    private fun exportSelected() {
        val src = archiveFile ?: run { toast("افتح IMG أولاً"); return }
        val e = entries.getOrNull(selected) ?: run { toast("اختر عنصراً أولاً"); return }
        val outName = displayName(e.index)
        runIo("جارٍ تجهيز التصدير...") {
            val f = File(cacheDir, "export_${e.index}.bin")
            RandomAccessFile(src, "r").use { r ->
                r.seek(e.offset)
                f.outputStream().use { o ->
                    val buf = ByteArray(1024 * 1024)
                    var left = e.size
                    while (left > 0) {
                        val n = r.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) throw EOFException()
                        o.write(buf, 0, n)
                        left -= n
                    }
                }
            }
            pendingExport = f
            runOnUiThread {
                startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, outName)
                    }, 13
                )
            }
        }
    }
    private fun deleteSelected() {
        if(archiveFile==null) { toast("افتح IMG أولاً"); return }; if(selected !in entries.indices) { toast("اختر عنصراً أولاً"); return }; if(entries.size==1) { toast("لا يمكن حذف آخر عنصر"); return }
        runIo("جارٍ حذف العنصر...") {
            val src=archiveFile!!
            val removedIndex=selected
            val oldRecords=nameTableRecords
            if (oldRecords != null) nameTableRecords=oldRecords.filterIndexed { i, _ -> i!=removedIndex }
            try {
                val p=entries.filterIndexed { i,_->i!=removedIndex }.map { Payload(src,it.offset,it.size) }
                val out=buildAfs(p)
                replaceArchive(out, parseAfs(out)); selected=-1
                refresh("تم الحذف. احفظ IMG جديداً.")
            } catch (t:Throwable) { nameTableRecords=oldRecords; throw t }
        }
    }
    private fun runIo(message:String,work:()->Unit) { info.text=message; io.execute { try { work() } catch(e:Throwable) { status("تعذر التنفيذ: ${e.message}") } } }
    // PES AFS غالباً لا يحتوي أسماء مفيدة؛ نستنتج الامتداد من ترويسة كل ملف.
    private fun rebuildEntryNames() {
        entryNames.clear()
        val src = archiveFile
        if (src == null) return
        RandomAccessFile(src, "r").use { r ->
            entries.forEach { e ->
                val magic = try {
                    if (e.size < 4) 0L else {
                        r.seek(e.offset)
                        val b = ByteArray(4); r.readFully(b)
                        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
                    }
                } catch (_: Throwable) { 0L }
                val ext = when {
                    magic == 0x00060100L -> "str"
                    magic == 0x00020000L -> "txs"
                    magic == 0x000E0100L -> "opd"
                    magic == 0x00010100L -> "fnt"
                    magic == 0x00050000L -> "flg"
                    (magic and 0xFFFF0000L) == 0x80000000L -> "adx"
                    else -> "bin"
                }
                entryNames.add("unnamed_${e.index}.$ext")
            }
        }
    }

    private fun displayName(index: Int): String =
        entryNames.getOrElse(index) { "unnamed_$index.bin" }

    private fun applySearch(query: String) {
        val q = query.trim().lowercase(Locale.ROOT)
        val normalized = q.map { ch -> when(ch) {
            in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
            in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
            else -> ch
        } }.joinToString("")
        displayLabels.clear()
        visibleIndices.clear()
        labels.forEachIndexed { index, label ->
            if (normalized.isEmpty() || label.lowercase(Locale.ROOT).contains(normalized) ||
                index.toString().contains(normalized)) {
                displayLabels.add(label)
                visibleIndices.add(index)
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun refresh(message: String) {
        rebuildEntryNames()
        runOnUiThread {
            labels.clear()
            entries.forEach { e ->
                val name = displayName(e.index)
                labels.add(String.format(Locale.US, "%s | %,d bytes | 0x%X", name, e.size, e.offset))
            }
            applySearch(searchBox.text?.toString().orEmpty())
            info.text = message
        }
    }
    private fun showSelected() {
        val e=entries.getOrNull(selected) ?: return
        info.text=String.format(Locale.US, "%s | index %d | offset 0x%X | %,d bytes",
            displayName(e.index), e.index, e.offset, e.size)
    }
    private fun status(s:String) { runOnUiThread { info.text=s } }
    private fun toast(s:String) { runOnUiThread { Toast.makeText(this,s,Toast.LENGTH_LONG).show() } }
    override fun onDestroy() { io.shutdown(); super.onDestroy() }
}
