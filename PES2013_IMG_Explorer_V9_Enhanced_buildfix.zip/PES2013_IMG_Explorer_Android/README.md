# PES 2013 IMG Explorer for Android — Alpha

An Android utility for inspecting and modifying PES 2013 PC AFS-based IMG archives.

## Current features

- Open IMG/AFS files using Android's document picker.
- Validate the `AFS\0` signature, entry count, table bounds and entry ranges.
- List entries as `Entry_0000.bin`, etc. (the basic AFS table has no filenames).
- Export a selected entry.
- Replace a selected entry.
- Add one or multiple files.
- Delete a selected entry.
- Rebuild the AFS table and payload area using 0x800-byte alignment.
- Save the modified archive as a new file; the source file is not overwritten.

## Verified sample format

The four sample files previously supplied (`dt04.img`, `dt05_a.img`, `dt05_r.img`, `dt0a.img`) use the `AFS\0` signature and a little-endian count followed by offset/size pairs. Their entry counts were 80, 74, 74 and 781 respectively. Non-empty payload offsets were aligned to `0x800`.

## Build requirements

- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.9 (downloaded automatically by the included Gradle Wrapper)

No Android Studio installation is required.

## Build locally or on a Linux cloud builder

From the project root:

```bash
./gradlew --no-daemon clean assembleDebug
```

Installable debug APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The project includes the complete Gradle Wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, and `gradle-wrapper.properties`). The wrapper downloads the pinned Gradle 8.9 distribution on first run.

## Code2Native cloud build

The project includes `code2native.json` at the project root. Upload the ZIP with the project files at its root, select Android source build and APK output, then inspect the build logs and download the artifact from the build page. Source compilation on Code2Native requires its Builder or Pro plan; its free preview is for wrapping a live website, not compiling native Android source.

## GitHub Actions build

The workflow at `.github/workflows/build-apk.yml` builds the same installable debug APK. Push the project to a GitHub repository and run the workflow from the Actions tab. Download the `PES2013-IMG-Explorer-debug-apk` artifact from the completed run.

## Compatibility cautions

- The basic AFS table does not contain filenames; entries are displayed by index.
- Adding or deleting entries changes the archive count and order. Some game archives may require their original count/order. Replacing an existing entry is the safest first test.
- The rebuild routine preserves extracted payload bytes but has not yet been validated in PES 2013 or against the original Windows utility after editing.
- Optional filename tables, PES-specific metadata, image decoding, zlib preview, folder navigation, undo and in-app preview are not implemented yet.

This is an alpha source build. Always keep an untouched backup of the original IMG file.
